# t0sic_inventoryui

Hello I decided to make my first release since I haven't really contributed to the community. Here is my Inventory UI.

### LICENSE

You are free to remake this however you wan't, however do not reupload it and do not sell it.
Credits To @Kalu / @Kashnars For Doing the money part, I just took their wallet script and remade it https://forum.fivem.net/t/release-allcity-wallet-esx/145419 If you wan't me to remove it please pm me

### REQUIERMENTS

You need ESX

### INSTALATION

Do not rename the resource, it won't work if you do

Simply drag and drop it in your resource folder and add it to your sever cfg. To add a picture for each item you need to go to assets -> css -> items.css and add the item you want with a # before and then specify what picture you wan't and the size of the picture. The name of the item you add has to be the exact as it is in the database and it's important that you're not adding the label but the name. I left some examples in the css folder. To open the meny press Y6

### INFO

This is a inventory script with a nice UI (see video)
* [PREVIEW VIDEO](https://streamable.com/5uo4t) 
